package nitchie.arruda.gurnee.chiluka.singing;

import java.util.List;

public class Singer {

	List<Byte[]> song;
	
	/**
	 * frequencies of notes
	 */
}
