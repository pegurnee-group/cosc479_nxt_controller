/** Automatically generated file. DO NOT MODIFY */
package nitchie.arruda.gurnee.chiluka.firstnxtproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}